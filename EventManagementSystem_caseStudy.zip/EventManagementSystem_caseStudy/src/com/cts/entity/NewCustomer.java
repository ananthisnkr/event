package com.cts.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@DiscriminatorValue(value = "N")
@XmlRootElement
public class NewCustomer extends Customer {
	
}
