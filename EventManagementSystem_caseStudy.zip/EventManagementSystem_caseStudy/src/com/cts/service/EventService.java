package com.cts.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.BookingDao;
import com.cts.entity.Customer;
import com.cts.entity.Event;
import com.cts.entity.Location;

@Path("/EventService")
public class EventService {

	@Path("/AddLocation")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	
	public Response AddLocationService(Location loc){
		
		BookingDao.insertLocationData(loc);
		
		return Response.status(200).header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").header("Access-Control-Allow-Credentials","true").header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").header("Access-Control-Max-Age",100052).entity(loc).build();	
		
	}
	
	
	@GET
	@Path("/GetLocation")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	
	public static Response getLocation()
	{
	//converting collection to Json
		System.out.println("in getlocation service");
		String message=BookingDao.getAll().size()+"received";
		System.out.println(message);
		GenericEntity<List<Location>> genentity1= new GenericEntity<List<Location>>(BookingDao.getAll()){};
		System.out.println("done");
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052)
				.entity(genentity1).build();	
	}
	
	@Path("/AddEvent")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	
	public Response AddEventService(Event event){
		System.out.println("in add event service");
		BookingDao.insertEventData(event);
		System.out.println("after insertion");
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052)
				.entity(event).build();	
		
	}
	
	
	@Path("/AddCustomer")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	
	public Response AddCustomerService(Customer cus){
		
		BookingDao.insertCustomerData(cus);
		
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052)
				.entity(cus).build();	
		
	}
	
	
	
	
	
}
