package com.cts.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;


//import com.cts.CustomerMaster;

@Entity
@Table(name="Eventdetails")
@XmlRootElement
public class Event implements Serializable{

	@Id
	@Column(name="event_id")
	private int eventId;



	@Column(name="event_name")
	private String eventName;
	
	@Temporal(TemporalType.DATE)
	@Column(name="event_date")
	private Date eventDate;
	
	@Column(name="tickets_available")
	private int ticketsAvailable;
	
	@OneToOne
	@JoinColumn(name="location_id")
	private Location location;

	
	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	

	public Date getEventDate() {
		return eventDate;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public int getTicketsAvailable() {
		return ticketsAvailable;
	}

	public void setTicketsAvailable(int ticketsAvailable) {
		this.ticketsAvailable = ticketsAvailable;
	}

	
	

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}


	
	
}
