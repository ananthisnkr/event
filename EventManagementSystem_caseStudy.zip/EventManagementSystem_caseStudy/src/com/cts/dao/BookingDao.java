package com.cts.dao;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.entity.Booking;
import com.cts.entity.Bookingc;
import com.cts.entity.Customer;
import com.cts.entity.Event;
import com.cts.entity.ExistingCustomer;
import com.cts.entity.Location;
import com.cts.entity.NewCustomer;
import com.cts.util.HibernateUtil;

/**
 * 
 * @author pejjac
 * 
 *         5) The customers can be classified into new customer and existing
 *         customer. Create the classes based on an Inheritance strategy wherein
 *         the New Customer will have to pay an membership fee of Rs 500 but the
 *         existing customer will be having an discount of 10% on the tickets
 *         booked � [AVERAGE]
 * 
 */

public class BookingDao {

	public static void main(String[] args) {
		/*Location location = new Location();
		location.setLocationId(1);
		location.setLocationName("kolkata");
		insertLocationData(location);
		*/// 2) Save Location_Master table
		//insertLocationData();
		// 3) Save Event_Master table
	//	insertEventData();
		// 1) Save Customer _ Master table
	//	insertCustomerData();
		// 5) The customers can be classified into new customer and existing
		// customer. Create the classes based on an Inheritance strategy wherein
		// the New Customer will have to pay an membership fee of Rs 500 but the
		// existing customer will be having an discount of 10% on the tickets
		// booked � [AVERAGE]
	//	getNewCustomerAmount(1, 1, 12, 120);
	//	getExsistingCustomerAmount(2, 1, 12, 120);
		//6) add customers to an event
	/*	System.out.println("Add customers to an event");
		 insertEvents(10,"Event1",new java.util.Date(),1);
		 insertEvents(15,"Event2", new java.util.Date(),1);
		 insertCustomers(20, "name1", "cust_address1");
		 insertCustomers(21, "name2", "cust_address2");
		 insertCustomers(23, "name3", "cust_address3");
		 addCustomerstoEvent(1, 30, 1);
	//	 addEventsToCustomer(10, 20, 2);
		//4) one to many between location and events
		
		
		// 7) Book tickets for an event based on the availability for a new
		// customer/ existing customer [AVERAGE]
		bookAticketForAnEventForAnExsistingCustomer(1, 2, 10);
		bookAticketForAnEventForNewCustomer(1, 1, 20);
		// 9) List the total sales amount for a
		// particular event � [SIMPLE]
		getAmountsForAnEvent(1);
		// 8) List the total number of tickets booked by an existing customer on
		// a particular month group by location � [SIMPLE]

		getTicketCountListByCustomerForALocationDuringSpecificMonth(1, 1);
*/	}

	public static void insertCustomerData(Customer cus) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		try{
		session.beginTransaction();
		System.out.println("Customer details in dao");
		System.out.println(cus.getCustAddress());
		//System.out.println(cus.getCustId());
		System.out.println(cus.getCustName());
		session.save(cus);
		session.getTransaction().commit();
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}
		System.out.println("Data inserted into customer master table");

	}
	
	

	public static void insertEventData(Event event) {
		System.out.println("in event insert dao");
		Location loc = new Location();
		loc.setLocationId(event.getLocation().getLocationId());
		SessionFactory factory =HibernateUtil.getSessionFactory();

		Session session = factory.openSession();
		try{
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(loc);
		event.setLocation(loc);
		session.save(event);
		
		transaction.commit();
		//session.close();
		System.out.println("Data inserted into Event master");
	}
		catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}

	}

	public static void insertLocationData(Location loc) {
		SessionFactory factory = HibernateUtil.getSessionFactory();

		Session session = factory.openSession();
		try{
		Transaction transaction = session.beginTransaction();
		//Location location = new Location();
		//location.setLocationId(1);
		//location.setLocationName("kolkata");
		session.save(loc);
		transaction.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}
		System.out.println("Data inserted into location master");
	}

	public static void getExsistingCustomerAmount(int cust_id, int event_id,
			int numberoftickets, float amount) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		try{
		Transaction transaction = session.beginTransaction();

		Query query = session
				.createQuery("from Customer b where b.class=? and custId =? ");
		query.setParameter(0, "E");
		query.setParameter(1, cust_id);
		List<Customer> list = (List<Customer>) query.list();
		Iterator it = list.iterator();
		float exsistingCustomerAmount = 0f;
		if (it.hasNext()) {
			Customer cust = (Customer) it.next();

			Booking booking = new Booking();
			Bookingc bookingc = new Bookingc();
			bookingc.setCustId(cust_id);
			bookingc.setEvent_id(event_id);
			booking.setTicketsBooked(numberoftickets);
			booking.setBookingc(bookingc);
			exsistingCustomerAmount = (amount - ((amount * 10) / 100));
			booking.setAmount(exsistingCustomerAmount);
			session.save(booking);
			transaction.commit();
			System.out.println(" Saving the discount Amount");

		}

		System.out.println("Existing customet doscount  = " + (amount * 10)
				/ 100);
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}
	}

	public static void getNewCustomerAmount(int cust_id, int event_id,
			int numberoftickets, float amount) {
		float customerMembershipAmount = 500.0f;
		SessionFactory factory =HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		float newCustomerAmount = 0f;
		try{
		Transaction transaction = session.beginTransaction();
		Query query = session
				.createQuery("from Customer b where b.class=? and custId =? ");
		query.setParameter(0, "N");
		query.setParameter(1, cust_id);
		List<Customer> list = (List<Customer>) query.list();
		Iterator it = list.iterator();
		
		if (it.hasNext()) {
			Customer cust = (Customer) it.next();

			Booking booking = new Booking();
			Bookingc bookingc = new Bookingc();
			bookingc.setCustId(cust_id);
			bookingc.setEvent_id(event_id);
			newCustomerAmount = (amount + customerMembershipAmount);
			booking.setAmount(newCustomerAmount);
			booking.setBookingc(bookingc);
			booking.setTicketsBooked(numberoftickets);
			session.save(booking);
			transaction.commit();
			
		}
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}
			System.out.println(" Saving the discount Amount");

		

		System.out
				.println("New customet total Amount including membership charge  = "
						+ (newCustomerAmount));
	}

	public static List<Location> getAll()
	{
		
		System.out.println("Calling getAll");
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		List<Location> loc=session.createQuery("from Location").list();
		
		//for(Location l:loc)
			//stem.out.println(l.getLocationId());
		return loc;
		//return session.createQuery("from Location").list();
	}
	
	
	static public void bookAticketForAnEventForAnExsistingCustomer(
			int event_id, int cust_id, int noOfTicketsRequired) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		try{
		Transaction transaction = session.beginTransaction();

		Query query = session
				.createQuery("from  Event event where  event.eventId =? ");
		query.setParameter(0, event_id);

		List list = query.list();

		Iterator it = list.iterator();

		float costPerTicket = 20.0f;

		if (it.hasNext()) {
			Event o = (Event) it.next();
			System.out.println(o.getTicketsAvailable());
			if (o.getTicketsAvailable() > noOfTicketsRequired) {
				float amount = noOfTicketsRequired * costPerTicket;
				float discount = ((amount * 10) / 100);
				float netAmount = amount - discount;
				Booking booking = new Booking();
				Bookingc bookingc = new Bookingc();
				bookingc.setEvent_id(event_id);
				bookingc.setCustId(cust_id);
				booking.setBookingc(bookingc);
				booking.setAmount(netAmount);
				booking.setTicketsBooked(noOfTicketsRequired);
				session.save(booking);

				System.out.println("Tickets Booked");
				o.setEventId(event_id);
				
				o.setTicketsAvailable((o.getTicketsAvailable() - noOfTicketsRequired));
				session.update(o);
				transaction.commit();
			
				System.out
						.println("Tickets availability is updated for an Event as  "
								+ (o.getTicketsAvailable()));

			} else {
				System.out.println("Available tickets ="
						+ o.getTicketsAvailable() + ", you can not book "
						+ noOfTicketsRequired + "Now");
			} } } 
			catch(HibernateException e){
				e.printStackTrace();
			}finally{
				if(session != null){
					session.close();
				}
			}
		

	}

	static public void bookAticketForAnEventForNewCustomer(int event_id,
			int cust_id, int noOfTicketsRequired) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		try{
		Transaction transaction = session.beginTransaction();

		Query query = session
				.createQuery("from  Event event where  event.eventId =? ");
		query.setParameter(0, event_id);

		List list = query.list();

		Iterator it = list.iterator();

		float costPerTicket = 20.0f;
		float membershipCharge = 500.0f;

		if (it.hasNext()) {
			Event o = (Event) it.next();
			System.out.println("tickets AVailable = "
					+ o.getTicketsAvailable());
			if (o.getTicketsAvailable() > noOfTicketsRequired) {
				float amount = noOfTicketsRequired * costPerTicket;

				float netAmount = amount + membershipCharge;
				Booking booking = new Booking();
				Bookingc bookingc = new Bookingc();
				bookingc.setEvent_id(event_id);
				bookingc.setCustId(cust_id);
				booking.setBookingc(bookingc);
				booking.setAmount(netAmount);
				booking.setTicketsBooked(noOfTicketsRequired);
				session.save(booking);

				System.out.println("Tickets Booked for New customer");
				o.setEventId(event_id);
				o.setTicketsAvailable((o.getTicketsAvailable() - noOfTicketsRequired));
				session.update(o);
				transaction.commit();
				System.out
						.println("Tickets available for an Event after booking  "
								+ (o.getTicketsAvailable()));

			} else {
				System.out.println("Available tickets ="
						+ o.getTicketsAvailable() + ", you can not book "
						+ noOfTicketsRequired + "Now");
			}
		}}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}

	}

	static void getAmountsForAnEvent(int eventId) {

		SessionFactory factory =HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		try{
		//Transaction transaction = session.beginTransaction();
		Query query = session
				.createQuery(" from Booking b where b.bookingc.eventId =?");
		query.setParameter(0, eventId);

		List<Booking> list = (List<Booking>) query.list();

		System.out.println("Booking Events list Size =" + list.size());
		int bookingCountforanEvent = 0;

		if (list.size() > 0) {

			for (Booking booking : list) {

				bookingCountforanEvent = bookingCountforanEvent + 1;
				System.out.println("Bookins = " + bookingCountforanEvent);

				System.out.println("The amout for bookking "
						+ (bookingCountforanEvent)
						+ " is  and booking Amount is =" + booking.getAmount());
			}
		} else {
			System.out.println("the event is not existing");
		}}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}

	}

	static void getTicketCountListByCustomerForALocationDuringSpecificMonth(
			int cust_id, int month) {

		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		try{
		Transaction transaction = session.beginTransaction();
		Query query = session
				.createQuery("select sum(b.ticketsBooked) from Booking b,  Event e where b.bookingc.custId=? "
						+ " and e.eventDate<= :date1 and e.eventDate>= :date2 and b.bookingc.eventId = e.eventId group by e.locationId");

		query.setParameter(0, cust_id);
		Calendar firstDayoftheMonth = Calendar.getInstance(); 
		firstDayoftheMonth.set(Calendar.DAY_OF_MONTH, 1);
		Date today = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(today);
		calendar.add(Calendar.MONTH, 1);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.add(Calendar.DATE, -1);
		Date lastDayOfMonth = calendar.getTime();
		query.setDate("date1", lastDayOfMonth);
		query.setDate("date2", firstDayoftheMonth.getTime());
		List l = query.list();
		System.out.println("List of total tickets Size = " + l.size());
		System.out.println(l.get(0));
		System.out.println("successfully done");
		}catch(HibernateException e){
			e.printStackTrace();
		}finally{
			if(session != null){
				session.close();
			}
		}

	}
	
	/* public static void addCustomerstoEvent(int lowerCustId,int upperCuatId,int eventCode){
		 // particular event 
		 
		 //this is not mandatory - to check for many-many
		 
		 SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		  try{
			  sf=HibernateUtil.getSessionFactory();
			  session=sf.openSession();
			   tr=session.beginTransaction();
			   Event c=(Event)session.load(Event.class,new Integer(eventCode));
			   Set s=c.getCustomers();
			   List l=session.createQuery("from Customer where custId between "+lowerCustId+" and "+upperCuatId).list();
			   for(int i=0;i<l.size();i++){
				   Customer customer=(Customer)l.get(i);
				   System.out.println("Customer: "+customer.getCustName());
			    s.add(customer);
			   }
			   c.setCustomers(s);
			   session.save(c);
			   tr.commit();
			   System.out.println("Customer added successfully");
			   
		  	}
		  catch(HibernateException e){
				 System.out.println(e+"  Error with Customer_MAster_event add block");
				 tr.rollback();
				// session.close();
			 }finally{
				 if(session!=null){
					 session.close();
				 }
			 }
	 }
	 
*/	 public static void addEventsToLocation(){
		 /*SessionFactory factory = HibernateUtil.getSessionFactory();

			Session session = factory.openSession();
			Transaction transaction = session.beginTransaction();
			try{
			

			Location location = new Location();
			location.setLocationId(53);
			location.setLocationName("Delhi");

			Set<Event> events = new HashSet<Event>();
			Event event1 = new Event();
			event1.setEventId(2);
			event1.setEventName("booking");
			event1.setEventDate(new Date());
			event1.setLocationId(53);
			event1.setTicketsAvailable(10);
			events.add(event1);
			
			Event event2 = new Event();
			event2.setEventId(3);
			event2.setEventName("booking1");
			event2.setEventDate(new Date());
			event2.setLocationId(53);
			event2.setTicketsAvailable(11);
			events.add(event2);
			
			location.setEventChildren(events);
			session.save(location);
			transaction.commit();
			System.out.println("Events per Delhi location = "+location.getEventChildren().size());
			}catch(HibernateException e){
				 System.out.println(e+"  Error with Customer_MAster_event add block");
				 transaction.rollback();
				// session.close();
			 }finally{
				 if(session!=null){
					 session.close();
				 }
*/


		//}
	 }
	 
	 public static void insertCustomers(int custId,String name,String custAddress){
			SessionFactory sf=null;
			  Session session=null;
			  Transaction tr=null;
			  try{
				  sf=HibernateUtil.getSessionFactory();
				  session=sf.openSession();
				   tr=session.beginTransaction();
				 
				   Customer c=new ExistingCustomer();
				   c.setCustId(custId);
				   c.setCustName(name);
				   c.setCustAddress(custAddress);
				   
				   session.save(c);
					  tr.commit();
				 }
			 
			 catch(HibernateException e){
				 System.out.println(e +"  Error with Customer insert block");
				 tr.rollback();
				 }finally{
			 
				 session.close();
			 }
		}
	/* 
	 public static void insertEvents(int id,String name, Date eventDate, int locationId){
			SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		  try{
			  sf=HibernateUtil.getSessionFactory();
			  session=sf.openSession();
			   tr=session.beginTransaction();
			   Event s=new Event();
			   s.setEventId(id);
			   s.setEventName(name);
			  // SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			  // Date eventDate1 = null;
			//try {
			//	eventDate1 = sdf.parse("05/01/2014");
			//} catch (ParseException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
			//}
			   s.setEventDate(eventDate);
			   s.setLocationId(locationId);
			   s.setTicketsAvailable(100);
				session.save(s);
			   tr.commit();
			 }
		 
		 catch(HibernateException e){
			 System.out.println(e+"  Error with Event insert block");
			 tr.rollback();
		 }finally{
			 session.close();
		 }
	 }
	
	 public static void addEventsToCustomer(int lowerCCode,int upperCCode,int customerCode){
		 // this is not mandatory - to check for many-many
		 System.out.println("Add events to customer");
		 SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		try {
			sf = HibernateUtil.getSessionFactory();
			session = sf.openSession();
			tr = session.beginTransaction();
			Customer s = (Customer) session.load(Customer.class,
					new Integer(customerCode));
			System.out.println("Customer info"+s.getCustId()+" "+s.getCustName());
			Set st = s.getEvents();
			List l = session.createQuery(
					"from Event where eventId between " + lowerCCode
							+ " and " + upperCCode).list();
			for (int i = 0; i < l.size(); i++) {
				Event eve = (Event) l.get(i);
				System.out.println("Event name : "+eve.getEventName());
				st.add(eve);
			}
			s.setEvents(st);
			session.save(s);
			tr.commit();
		}
		  catch(HibernateException e){
				 System.out.println(e+"  Error with Event_customer add block");
				 tr.rollback();
			}
		  finally{
				 session.close();
			 }
	 }
*/
}