package com.cts.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@DiscriminatorValue( value="E")
@XmlRootElement
public class ExistingCustomer extends Customer{
    

}
